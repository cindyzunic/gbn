#!/bin/bash

java -cp . com.gbn.sender $1 $2 $3 "$4"
