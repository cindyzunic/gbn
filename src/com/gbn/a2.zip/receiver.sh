#!/bin/bash

java -cp . com.gbn.receiver $1 $2 $3 "$4" 

